function getProduct() {
    var prodName = document.getElementById("pname");
    return prodName;
}